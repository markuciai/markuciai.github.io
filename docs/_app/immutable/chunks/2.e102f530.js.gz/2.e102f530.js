import{default as t}from"../entry/_page.svelte.d8f5dc5a.js";export{t as component};
