import{default as t}from"../entry/error.svelte.70bf6fa5.js";export{t as component};
