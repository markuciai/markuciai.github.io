import{default as t}from"../entry/lobis-kryzius-page.svelte.d8f5dc5a.js";export{t as component};
